package pt.ulusofona.deisi.a2020.cm.g6

class Regiao(var nome:String, var casosTotais: String, var casosUltima: Int, var srcImage: String) {

}