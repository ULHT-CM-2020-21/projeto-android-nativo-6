# Projeto Android Nativo Grupo 6

## Pedido Enunciado

Numero Grupo: 6  
Realizado Por:  
Martim Mourão 21805485  
Gonçalo Évora 21805468  
LINK YOUTUBE: #TODO  

## Autoavaliação  
Dashboard 3  
Registo de testes 2  
Listagem de testes 2  
Detalhe dos testes 2  
Estou em perigo 2  
Contactos 2  
Suporte multi-idioma 1  
Extra 3  
Participação no Piazza 1  
Video 2  
TOTAL: #TODO   

# Dicionario Dados

https://github.com/dssg-pt/covid19pt-data#-dicion%C3%A1rio-dos-dados

## Introdução
Face ao excelente desempenho dos alunos no projeto anterior, a empresa
iQueChumbei decidiu adjudicar outro projecto à universidade 😁. Nos dias que correm a
circulação da informação é particularmente importante, especialmente no que diz respeito à
pandemia causada pela Covid-19. Desta forma, pretende-se que desenvolvam uma aplicação
móvel (nativa) Android, que informe os utilizadores eficazmente sobre o estado atual da
pandemia no país (apenas em Portugal).
O nome da aplicação assim como o esquema de cores ficarão completamente a cargo
da criatividade dos alunos.

# Bibliografia & Links 

https://android-arsenal.com/  
https://github.com/dssg-pt/covid19pt-data/blob/master/data.csv


