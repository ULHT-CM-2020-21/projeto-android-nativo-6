package pt.ulusofona.deisi.a2020.cm.g6.ui.detalheTeste

import android.app.Application
import androidx.lifecycle.AndroidViewModel

class DetalheTesteViewModel (application: Application): AndroidViewModel(application){
}