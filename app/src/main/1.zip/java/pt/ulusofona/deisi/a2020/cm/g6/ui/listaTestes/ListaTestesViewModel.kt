package pt.ulusofona.deisi.a2020.cm.g6.ui.listaTestes

import android.app.Application
import androidx.lifecycle.AndroidViewModel

class ListaTestesViewModel (application: Application): AndroidViewModel(application){
}