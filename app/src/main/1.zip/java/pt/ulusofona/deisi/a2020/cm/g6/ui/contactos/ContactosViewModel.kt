package pt.ulusofona.deisi.a2020.cm.g6.ui.contactos

import android.app.Application
import androidx.lifecycle.AndroidViewModel

class ContactosViewModel (application: Application): AndroidViewModel(application){
}