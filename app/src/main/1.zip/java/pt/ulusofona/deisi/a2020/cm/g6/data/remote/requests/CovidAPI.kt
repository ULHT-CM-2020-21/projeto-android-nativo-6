package pt.ulusofona.deisi.a2020.cm.g6.data.remote.requests

class CovidAPI () {
}