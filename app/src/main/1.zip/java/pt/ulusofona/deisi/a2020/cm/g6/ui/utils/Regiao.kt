package pt.ulusofona.deisi.a2020.cm.g6.ui.utils

class Regiao(var nome:String, var casosTotais: String, var casosUltima: String, var srcImage: String) {

}