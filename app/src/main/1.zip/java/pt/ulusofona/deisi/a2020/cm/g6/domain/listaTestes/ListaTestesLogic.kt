package pt.ulusofona.deisi.a2020.cm.g6.domain.listaTestes

class ListaTestesLogic {
}